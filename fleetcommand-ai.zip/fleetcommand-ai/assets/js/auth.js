/* ===========================================================
   FleetCommand AI — Mock Auth Layer
   Data lives in localStorage so the demo persists between pages.
   =========================================================== */
const FC_DB_KEY = 'fc_users_db';
const FC_SESSION_KEY = 'fc_session';

/* ---- Seed demo accounts (created once) ---- */
function fcSeedDB(){
  let db = JSON.parse(localStorage.getItem(FC_DB_KEY) || 'null');
  if(!db){
    db = [
      {
        role: 'admin',
        name: 'Priya Nandan',
        email: 'admin@fleetcommand.ai',
        password: 'Admin@123',
        phone: '+1 (555) 000-1111',
        fixed: true
      },
      {
        role: 'user',
        name: 'Alexander Sterling',
        email: 'user@demo.com',
        password: 'User@123',
        phone: '+1 (555) 234-8901',
        jobRole: 'Fleet Operations Manager'
      },
      {
        role: 'owner',
        name: 'Marcus Chen',
        email: 'owner@demo.com',
        password: 'Owner@123',
        phone: '+1 (555) 678-2233',
        company: 'SwiftLogistics Partners'
      }
    ];
    localStorage.setItem(FC_DB_KEY, JSON.stringify(db));
  }
  return db;
}

function fcGetDB(){ return fcSeedDB(); }
function fcSaveDB(db){ localStorage.setItem(FC_DB_KEY, JSON.stringify(db)); }

/* ---- Register ---- */
function fcRegister({name, email, phone, password, role, extra}){
  const db = fcGetDB();
  if(db.find(u => u.email.toLowerCase() === email.toLowerCase())){
    return { ok:false, message: 'An account with this email already exists.' };
  }
  const user = { role, name, email, password, phone, ...extra };
  db.push(user);
  fcSaveDB(db);
  fcSetSession(user);
  return { ok:true, user };
}

/* ---- Login ---- */
function fcLogin(email, password){
  const db = fcGetDB();
  const user = db.find(u => u.email.toLowerCase() === email.toLowerCase());
  if(!user) return { ok:false, message: 'No account found for that email.' };
  if(user.password !== password) return { ok:false, message: 'Incorrect password. Please try again.' };
  fcSetSession(user);
  return { ok:true, user };
}

function fcSetSession(user){
  const session = { email:user.email, role:user.role, name:user.name };
  localStorage.setItem(FC_SESSION_KEY, JSON.stringify(session));
}

function fcGetSession(){
  return JSON.parse(localStorage.getItem(FC_SESSION_KEY) || 'null');
}

function fcGetCurrentUser(){
  const session = fcGetSession();
  if(!session) return null;
  const db = fcGetDB();
  return db.find(u => u.email === session.email) || null;
}

function fcUpdateCurrentUser(patch){
  const session = fcGetSession();
  if(!session) return;
  const db = fcGetDB();
  const idx = db.findIndex(u => u.email === session.email);
  if(idx > -1){
    db[idx] = { ...db[idx], ...patch };
    fcSaveDB(db);
    if(patch.name) fcSetSession(db[idx]);
  }
}

function fcLogout(){
  localStorage.removeItem(FC_SESSION_KEY);
  window.location.href = fcRootPath() + 'login.html';
}

/* Works out how many folders deep the current page is, so links to
   root-level pages (login.html, index.html) resolve correctly from
   /user/, /owner/ and /admin/ subfolders. */
function fcRootPath(){
  const path = window.location.pathname;
  if(path.includes('/user/') || path.includes('/owner/') || path.includes('/admin/')){
    return '../';
  }
  return '';
}

/* Guards a dashboard page: redirects to login if not authenticated,
   or if the session role does not match the page's required role. */
function fcRequireAuth(requiredRole){
  const session = fcGetSession();
  if(!session){
    window.location.href = fcRootPath() + 'login.html';
    return null;
  }
  if(requiredRole && session.role !== requiredRole){
    window.location.href = fcRootPath() + session.role + '/dashboard.html';
    return null;
  }
  return session;
}

function fcToast(message, type=''){
  let el = document.getElementById('toast');
  if(!el){
    el = document.createElement('div');
    el.id = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.className = type;
  requestAnimationFrame(()=> el.classList.add('show'));
  clearTimeout(el._t);
  el._t = setTimeout(()=> el.classList.remove('show'), 2600);
}

fcSeedDB();
