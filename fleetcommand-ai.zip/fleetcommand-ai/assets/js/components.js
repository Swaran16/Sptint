/* ===========================================================
   FleetCommand AI — Shared Shell Components (sidebar + header)
   Injected via JS so every screen in a role shares one source
   of truth instead of duplicated markup per page.
   =========================================================== */

const FC_ICONS = {
  dashboard: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>',
  trips: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 3v18M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3V6z"/></svg>',
  bookings: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M3 10h18M8 2v4M16 2v4"/></svg>',
  payments: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>',
  profile: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>',
  fleet: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 13l2-7h14l2 7"/><rect x="3" y="13" width="18" height="6" rx="1.5"/><circle cx="7.5" cy="19" r="1.3"/><circle cx="16.5" cy="19" r="1.3"/></svg>',
  earnings: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/></svg>',
  verifications: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M9 12l2 2 4-4"/></svg>',
  users: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-6 6.5-6s6.5 2.5 6.5 6"/><circle cx="18" cy="8" r="2.7"/><path d="M16 8.3A5.5 5.5 0 0121.5 14"/></svg>',
  reports: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
  settings: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.9 2.9l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.6V21a2 2 0 11-4 0v-.2a1.7 1.7 0 00-1-1.6 1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.9-2.9l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.6-1H3a2 2 0 110-4h.2a1.7 1.7 0 001.6-1 1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.9-2.9l.1.1a1.7 1.7 0 001.9.3H9a1.7 1.7 0 001-1.6V3a2 2 0 114 0v.2a1.7 1.7 0 001 1.6 1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.9 2.9l-.1.1a1.7 1.7 0 00-.3 1.9V9a1.7 1.7 0 001.6 1h.2a2 2 0 110 4h-.2a1.7 1.7 0 00-1.6 1z"/></svg>',
  logout: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>',
  bell: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 01-3.4 0"/></svg>',
  gear: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.9 2.9l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.6V21a2 2 0 11-4 0v-.2a1.7 1.7 0 00-1-1.6 1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.9-2.9l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.6-1H3a2 2 0 110-4h.2a1.7 1.7 0 001.6-1 1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.9-2.9l.1.1a1.7 1.7 0 001.9.3H9a1.7 1.7 0 001-1.6V3a2 2 0 114 0v.2a1.7 1.7 0 001 1.6 1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.9 2.9l-.1.1a1.7 1.7 0 00-.3 1.9V9a1.7 1.7 0 001.6 1h.2a2 2 0 110 4h-.2a1.7 1.7 0 00-1.6 1z"/></svg>',
  search: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/></svg>'
};

const FC_NAV = {
  user: [
    { key:'dashboard', label:'Dashboard', href:'dashboard.html', icon:'dashboard' },
    { key:'trips', label:'Trips', href:'trips.html', icon:'trips' },
    { key:'bookings', label:'Bookings', href:'bookings.html', icon:'bookings' },
    { key:'payments', label:'Payments', href:'payments.html', icon:'payments' },
    { key:'profile', label:'Profile', href:'profile.html', icon:'profile' },
  ],
  owner: [
    { key:'dashboard', label:'Dashboard', href:'dashboard.html', icon:'dashboard' },
    { key:'fleet', label:'My Fleet', href:'fleet.html', icon:'fleet' },
    { key:'drivers', label:'Drivers', href:'drivers.html', icon:'profile' },
    { key:'bookings', label:'Bookings', href:'bookings.html', icon:'bookings' },
    { key:'earnings', label:'Earnings', href:'earnings.html', icon:'earnings' },
    { key:'profile', label:'Profile', href:'profile.html', icon:'profile' },
  ],
  admin: [
    { key:'dashboard', label:'Dashboard', href:'dashboard.html', icon:'dashboard' },
    { key:'verifications', label:'Verifications', href:'verifications.html', icon:'verifications' },
    { key:'owners', label:'Owners List', href:'owners.html', icon:'users' },
    { key:'bookings', label:'Bookings', href:'bookings.html', icon:'bookings' },
    { key:'settings', label:'Settings', href:'settings.html', icon:'settings' },
  ]
};

const FC_ROLE_META = {
  user: { title:'FleetCommand AI', sub:'Enterprise Logistics', newBtn:{label:'New Booking', href:'bookings.html'} },
  owner:{ title:'FleetCommand AI', sub:'Owner Portal', newBtn:{label:'Add Vehicle', href:'fleet.html'} },
  admin:{ title:'FleetCommand AI', sub:'Admin Portal', newBtn:{label:'Verifications', href:'verifications.html'} },
};

function fcInitials(name){
  return name.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase();
}

function fcRenderShell({ role, active }){
  const session = fcRequireAuth(role);
  if(!session) return;
  const user = fcGetCurrentUser();
  const nav = FC_NAV[role];
  const meta = FC_ROLE_META[role];

  let sidebarHTML = '';
  if (role !== 'user') {
    sidebarHTML = `
      <aside class="sidebar">
        <div>
          <div class="brand"><span class="brand-mark">${roleMark()}</span>${meta.title}</div>
          <p class="brand-sub">${meta.sub}</p>
          <nav class="side-nav">
            ${nav.map(item => `
              <a href="${item.href}" class="${active===item.key ? 'active':''}">
                ${FC_ICONS[item.icon]} ${item.label}
              </a>`).join('')}
          </nav>
        </div>
        <div class="sidebar-bottom">
          <a href="${meta.newBtn.href}" class="btn btn-primary btn-block btn-sm">+ ${meta.newBtn.label}</a>
          <a href="#" class="logout-link" id="logoutLink">${FC_ICONS.logout} Logout</a>
        </div>
      </aside>`;
  }

  let topbarHTML = '';
  if (role === 'user') {
    topbarHTML = `
      <header class="topbar" style="justify-content: space-between; padding: 16px 34px;">
        <div class="brand" style="display:flex; align-items:center; gap:8px;">
          <span class="brand-mark" style="background: var(--indigo-600); width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; border-radius:8px; color:#fff;">
            ${roleMark()}
          </span>
          <span style="font-family: var(--font-display); font-weight:700; font-size:19px; color: var(--ink-900);">FleetCommand AI</span>
        </div>
        
        <nav class="topbar-nav" style="display:flex; gap:32px; font-size:14.5px; font-weight:600; color: var(--ink-600); margin: 0 auto 0 40px;">
          <a href="dashboard.html" class="${active==='dashboard' ? 'active':''}" style="color: ${active==='dashboard' ? 'var(--indigo-700)':'inherit'}; display: flex; align-items: center; gap: 6px;">
            Home
          </a>
          <a href="bookings.html" class="${active==='bookings' ? 'active':''}" style="color: ${active==='bookings' ? 'var(--indigo-700)':'inherit'}; display: flex; align-items: center; gap: 6px;">
            Bookings
          </a>
          <a href="trips.html" class="${active==='trips' ? 'active':''}" style="color: ${active==='trips' ? 'var(--indigo-700)':'inherit'}; display: flex; align-items: center; gap: 6px;">
            Trips
          </a>
        </nav>

        <div class="topbar-actions">
          <button class="icon-btn" title="Notifications">${FC_ICONS.bell}<span class="dot"></span></button>
          <div class="avatar-menu-wrap">
            <button class="avatar" id="avatarBtn">${fcInitials(user.name)}</button>
            <div class="avatar-dropdown" id="avatarDropdown">
              <div class="user-meta"><strong>${user.name}</strong><span>${user.email}</span></div>
              <a href="profile.html">${FC_ICONS.profile} My Profile</a>
              <a href="payments.html">${FC_ICONS.payments} Payments & Invoices</a>
              <button id="logoutBtn" style="border-top: 1px solid var(--line); border-radius: 0; margin-top: 5px; padding-top: 12px; color: var(--danger);">${FC_ICONS.logout} Logout</button>
            </div>
          </div>
        </div>
      </header>`;
  } else {
    topbarHTML = `
      <header class="topbar">
        <div class="topbar-search">
          <div class="input-wrap">
            ${FC_ICONS.search}
            <input type="text" placeholder="Search trips, bookings, or IDs..." id="globalSearch">
          </div>
        </div>
        <div class="topbar-actions">
          <button class="icon-btn" title="Notifications">${FC_ICONS.bell}<span class="dot"></span></button>
          <a href="settings.html" class="icon-btn" title="Settings">${FC_ICONS.gear}</a>
          <div class="avatar-menu-wrap">
            <button class="avatar" id="avatarBtn">${fcInitials(user.name)}</button>
            <div class="avatar-dropdown" id="avatarDropdown">
              <div class="user-meta"><strong>${user.name}</strong><span>${user.email}</span></div>
              <a href="${role==='admin' ? 'settings.html' : 'profile.html'}">${FC_ICONS.profile} My Profile</a>
              <button id="logoutBtn">${FC_ICONS.logout} Logout</button>
            </div>
          </div>
        </div>
      </header>`;
  }

  const sidebarMount = document.getElementById('sidebar-mount');
  if (sidebarMount) {
    if (sidebarHTML) {
      sidebarMount.outerHTML = sidebarHTML;
    } else {
      sidebarMount.remove();
    }
  }

  const topbarMount = document.getElementById('topbar-mount');
  if (topbarMount) {
    topbarMount.outerHTML = topbarHTML;
  }

  const logoutLink = document.getElementById('logoutLink');
  if (logoutLink) {
    logoutLink.addEventListener('click', (e)=>{ e.preventDefault(); fcLogout(); });
  }

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', fcLogout);
  }

  const avBtn = document.getElementById('avatarBtn');
  if (avBtn) {
    avBtn.addEventListener('click', ()=>{
      document.getElementById('avatarDropdown').classList.toggle('open');
    });
  }
  document.addEventListener('click', (e)=>{
    const wrap = document.querySelector('.avatar-menu-wrap');
    if(wrap && !wrap.contains(e.target)) {
      const drop = document.getElementById('avatarDropdown');
      if (drop) drop.classList.remove('open');
    }
  });

  // Inject Floating Demo Portal Switcher for seamless workflow testing
  if(!document.getElementById('fcDemoSwitcher')) {
    const switcher = document.createElement('div');
    switcher.id = 'fcDemoSwitcher';
    switcher.innerHTML = `
      <div style="position:fixed; bottom:20px; right:20px; background:#1e1e2d; color:#fff; padding:10px 14px; border-radius:8px; box-shadow:0 6px 20px rgba(0,0,0,0.35); display:flex; gap:8px; align-items:center; font-family:system-ui, -apple-system, sans-serif; font-size:12px; z-index:99999; border:1px solid rgba(255,255,255,0.15);">
        <span style="font-weight:700; color:rgba(255,255,255,0.55); text-transform:uppercase; font-size:10px; letter-spacing:0.5px; margin-right:4px;">Demo Switcher:</span>
        <button onclick="fcDemoSwitch('admin')" style="background:${role==='admin'?'var(--indigo-600)':'rgba(255,255,255,0.1)'}; color:#fff; border:none; padding:5px 9px; border-radius:4px; font-weight:600; cursor:pointer; font-size:11px; transition:background 0.2s;">Admin</button>
        <button onclick="fcDemoSwitch('owner')" style="background:${role==='owner'?'var(--indigo-600)':'rgba(255,255,255,0.1)'}; color:#fff; border:none; padding:5px 9px; border-radius:4px; font-weight:600; cursor:pointer; font-size:11px; transition:background 0.2s;">Owner</button>
        <button onclick="fcDemoSwitch('user')" style="background:${role==='user'?'var(--indigo-600)':'rgba(255,255,255,0.1)'}; color:#fff; border:none; padding:5px 9px; border-radius:4px; font-weight:600; cursor:pointer; font-size:11px; transition:background 0.2s;">User</button>
      </div>
    `;
    document.body.appendChild(switcher);
  }

  window.fcDemoSwitch = function(targetRole) {
    let email = '';
    let password = '';
    if(targetRole === 'admin') {
      email = 'admin@fleetcommand.ai';
      password = 'Admin@123';
    } else if(targetRole === 'owner') {
      email = 'owner@demo.com';
      password = 'Owner@123';
    } else if(targetRole === 'user') {
      email = 'user@demo.com';
      password = 'User@123';
    }
    
    const result = fcLogin(email, password);
    if(result.ok) {
      window.location.href = fcRootPath() + targetRole + '/dashboard.html';
    }
  }

  return { session, user };
}

function roleMark(){
  return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12l7-9 4 4-7 9-4-4z"/><path d="M13 7l4-4 4 4-7 9"/></svg>';
}
