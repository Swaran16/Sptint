// =====================================================================
// FleetCommand AI — Vehicle Data Store
// Loads frontend/data/vehicles.json and exposes filter/sort/paginate
// helpers shared by search.html and vehicle-details.html.
// =====================================================================

(function () {
  'use strict';

  var _vehicles = null;   // cache once fetched
  var _loadPromise = null;

  function jsonUrl() {
    // Resolve relative to this script's own location so it works
    // whether the page lives at /frontend/*.html or /frontend/customer/*.html
    var scripts = document.getElementsByTagName('script');
    for (var i = 0; i < scripts.length; i++) {
      var src = scripts[i].src || '';
      if (src.indexOf('js/vehicles.js') !== -1) {
        return src.replace('js/vehicles.js', 'data/vehicles.json');
      }
    }
    return '../data/vehicles.json';
  }

  function load() {
    if (_loadPromise) return _loadPromise;
    _loadPromise = fetch(jsonUrl())
      .then(function (res) {
        if (!res.ok) throw new Error('Failed to load vehicles.json: ' + res.status);
        return res.json();
      })
      .then(function (data) {
        _vehicles = data.vehicles || [];
        return _vehicles;
      });
    return _loadPromise;
  }

  function getAll() {
    return load();
  }

  function getById(id) {
    return load().then(function (list) {
      return list.find(function (v) { return v.id === id; }) || null;
    });
  }

  // criteria: { vehicleType: [], fuelType: [], transmission: '', maxPrice: n, location: '', query: '' }
  function filter(list, criteria) {
    criteria = criteria || {};
    return list.filter(function (v) {
      if (criteria.vehicleType && criteria.vehicleType.length && criteria.vehicleType.indexOf(v.vehicleType) === -1) return false;
      if (criteria.fuelType && criteria.fuelType.length && criteria.fuelType.indexOf(v.fuelType) === -1) return false;
      if (criteria.transmission && v.transmission !== criteria.transmission) return false;
      if (criteria.maxPrice != null && v.dailyRate > criteria.maxPrice) return false;
      if (criteria.location) {
        var loc = criteria.location.toLowerCase();
        var matches = (v.pickupLocations || []).some(function (p) { return p.toLowerCase().indexOf(loc) !== -1; });
        if (!matches) return false;
      }
      if (criteria.query) {
        var q = criteria.query.toLowerCase();
        var hay = (v.make + ' ' + v.model).toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });
  }

  function sort(list, sortKey) {
    var sorted = list.slice();
    switch (sortKey) {
      case 'price_asc':
        sorted.sort(function (a, b) { return a.dailyRate - b.dailyRate; });
        break;
      case 'price_desc':
        sorted.sort(function (a, b) { return b.dailyRate - a.dailyRate; });
        break;
      case 'rating_desc':
        sorted.sort(function (a, b) { return b.rating - a.rating; });
        break;
      case 'newest':
        sorted.sort(function (a, b) { return b.year - a.year; });
        break;
      default:
        // "Recommended" — bookings desc as a stand-in relevance signal
        sorted.sort(function (a, b) { return b.totalBookings - a.totalBookings; });
    }
    return sorted;
  }

  function paginate(list, page, perPage) {
    page = Math.max(1, page || 1);
    perPage = perPage || 6;
    var totalPages = Math.max(1, Math.ceil(list.length / perPage));
    page = Math.min(page, totalPages);
    var start = (page - 1) * perPage;
    return {
      items: list.slice(start, start + perPage),
      page: page,
      perPage: perPage,
      totalItems: list.length,
      totalPages: totalPages
    };
  }

  function capacityLabel(v) {
    return v.capacity && v.capacity.label ? v.capacity.label : '';
  }

  function mileageLabel(v) {
    return v.mileage && v.mileage.label ? v.mileage.label : '';
  }

  function vehicleTypeLabel(v) {
    return { car: 'Car', truck: 'Truck', mini_truck: 'Mini Truck' }[v.vehicleType] || v.vehicleType;
  }

  window.VehicleStore = {
    load: load,
    getAll: getAll,
    getById: getById,
    filter: filter,
    sort: sort,
    paginate: paginate,
    capacityLabel: capacityLabel,
    mileageLabel: mileageLabel,
    vehicleTypeLabel: vehicleTypeLabel
  };
})();
