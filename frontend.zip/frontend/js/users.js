// =====================================================================
// FleetCommand AI — Users Data Store & Auth Session
// Manages Sign-in, Sign-up, localStorage storage, and Cookie sessions.
// =====================================================================

(function () {
  'use strict';

  var USERS_KEY = 'FC_USERS';
  var SESSION_COOKIE = 'FC_SESSION';

  // Cookie helpers
  function setCookie(name, value, days) {
    var expires = "";
    if (days) {
      var date = new Date();
      date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
      expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + encodeURIComponent(value) + expires + "; path=/";
  }

  function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) === 0) return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
    return null;
  }

  function eraseCookie(name) {
    document.cookie = name + '=; Max-Age=-99999999; path=/';
  }

  // Load initial users from JSON if local storage is blank
  function initStore() {
    if (localStorage.getItem(USERS_KEY)) {
      return Promise.resolve(JSON.parse(localStorage.getItem(USERS_KEY)));
    }

    // Resolve relative path to data/users.json
    var jsonUrl = '../data/users.json';
    var scripts = document.getElementsByTagName('script');
    for (var i = 0; i < scripts.length; i++) {
      var src = scripts[i].src || '';
      if (src.indexOf('js/users.js') !== -1) {
        jsonUrl = src.replace('js/users.js', 'data/users.json');
        break;
      }
    }

    return fetch(jsonUrl)
      .then(function (res) {
        if (!res.ok) throw new Error('Could not fetch users.json');
        return res.json();
      })
      .then(function (data) {
        var list = data.users || [];
        localStorage.setItem(USERS_KEY, JSON.stringify(list));
        return list;
      })
      .catch(function (err) {
        console.warn('Using default fallback users:', err);
        var fallbacks = [
          { id: "USR-CUS-101", email: "customer@fleet.in", password: "Password@123", name: "Ravi Patel", role: "customer" },
          { id: "USR-OWN-101", email: "owner@fleet.in", password: "Password@123", name: "Blue Peak Logistics", role: "owner" },
          { id: "USR-DRV-101", email: "driver@fleet.in", password: "Password@123", name: "Marcus Rivera", role: "driver" },
          { id: "USR-ADM-101", email: "admin@fleet.in", password: "Password@123", name: "System Admin", role: "admin" }
        ];
        localStorage.setItem(USERS_KEY, JSON.stringify(fallbacks));
        return fallbacks;
      });
  }

  function getUsers() {
    return initStore();
  }

  function signIn(email, password) {
    return getUsers().then(function (list) {
      var user = list.find(function (u) {
        return u.email.toLowerCase() === email.toLowerCase() && u.password === password;
      });
      if (!user) {
        throw new Error('Invalid email or password.');
      }
      
      // Save session in cookie (expires in 7 days)
      var sessionData = {
        userId: user.id,
        role: user.role,
        name: user.name,
        email: user.email,
        phone: user.phone || ''
      };
      setCookie(SESSION_COOKIE, JSON.stringify(sessionData), 7);
      return user;
    });
  }

  function signUp(name, email, password, role, phone) {
    return getUsers().then(function (list) {
      var exists = list.some(function (u) {
        return u.email.toLowerCase() === email.toLowerCase();
      });
      if (exists) {
        throw new Error('An account with this email already exists.');
      }

      var newUser = {
        id: 'USR-' + role.substring(0, 3).toUpperCase() + '-' + Date.now(),
        name: name,
        email: email,
        password: password,
        role: role,
        phone: phone || ''
      };

      list.push(newUser);
      localStorage.setItem(USERS_KEY, JSON.stringify(list));

      // Save session in cookie (expires in 7 days)
      var sessionData = {
        userId: newUser.id,
        role: newUser.role,
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone
      };
      setCookie(SESSION_COOKIE, JSON.stringify(sessionData), 7);
      return newUser;
    });
  }

  function getCurrentSession() {
    var cookieVal = getCookie(SESSION_COOKIE);
    if (!cookieVal) return null;
    try {
      return JSON.parse(cookieVal);
    } catch (e) {
      return null;
    }
  }

  function signOut() {
    eraseCookie(SESSION_COOKIE);
  }

  // Self-initializing
  initStore();

  // DOM setup: Swap Sign In button with User badge / Profile button / Sign Out button
  if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', function() {
      var session = getCurrentSession();
      if (!session) return;

      var relativeProfile = './profile.html';
      var path = window.location.pathname;
      if (path.indexOf('/customer/') !== -1 || path.indexOf('/owner/') !== -1 || path.indexOf('/driver/') !== -1 || path.indexOf('/admin/') !== -1) {
        relativeProfile = '../profile.html';
      }
      
      var signInLinks = document.querySelectorAll('a[href*="signin.html"]');
      signInLinks.forEach(function(link) {
        var container = link.parentElement;
        if (container) {
          container.innerHTML = 
            '<div class="flex items-center gap-sm">' +
              '<span class="text-xs font-semibold text-on-surface-variant font-label-md">Hi, ' + session.name + '</span>' +
              '<a href="' + relativeProfile + '" class="px-md py-sm rounded-lg font-label-md bg-primary text-on-primary text-xs hover:opacity-90 active:scale-95 transition-all">Profile</a>' +
              '<button id="headerSignOutBtn" class="px-md py-sm rounded-lg font-label-md border border-outline-variant text-on-surface hover:bg-surface-container transition-all active:scale-95 text-xs">Sign Out</button>' +
            '</div>';

          var btn = document.getElementById('headerSignOutBtn');
          if (btn) {
            btn.addEventListener('click', function(e) {
              e.preventDefault();
              signOut();
              window.location.reload();
            });
          }
        }
      });
    });
  }

  window.UserStore = {
    signIn: signIn,
    signUp: signUp,
    getCurrentSession: getCurrentSession,
    signOut: signOut
  };
})();
