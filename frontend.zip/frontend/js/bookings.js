// =====================================================================
// FleetCommand AI — Bookings Data Store
// Manages adding, querying, and persisting bookings linked to User Session
// =====================================================================

(function () {
  'use strict';

  var BOOKINGS_KEY = 'FC_BOOKINGS';

  function initStore() {
    if (localStorage.getItem(BOOKINGS_KEY)) {
      return Promise.resolve(JSON.parse(localStorage.getItem(BOOKINGS_KEY)));
    }

    var jsonUrl = '../data/bookings.json';
    // Handle path resolution depending on where this is loaded
    var scripts = document.getElementsByTagName('script');
    for (var i = 0; i < scripts.length; i++) {
      var src = scripts[i].src || '';
      if (src.indexOf('js/bookings.js') !== -1) {
        jsonUrl = src.replace('js/bookings.js', 'data/bookings.json');
        break;
      }
    }

    return fetch(jsonUrl)
      .then(function (res) {
        if (!res.ok) throw new Error('Could not fetch bookings.json');
        return res.json();
      })
      .then(function (data) {
        var list = data.bookings || [];
        localStorage.setItem(BOOKINGS_KEY, JSON.stringify(list));
        return list;
      })
      .catch(function (err) {
        console.warn('Using default fallback bookings:', err);
        var fallbacks = [
          {
            id: "FCA-2024-00847",
            userId: "USR-CUS-101",
            vehicleId: "VEH-001",
            pickupLoc: "Mumbai Airport Hub T2",
            dropoffLoc: "Pune Hinjewadi Hub",
            startDate: "2026-07-10",
            endDate: "2026-07-13",
            distance: 150,
            days: 3,
            totalPrice: 42600,
            vehicleName: "Tesla Model 3 Performance",
            vehicleInfo: "Electric • 5 Seats • 490km Range",
            fuelType: "electric",
            status: "confirmed",
            createdAt: new Date().toISOString()
          }
        ];
        localStorage.setItem(BOOKINGS_KEY, JSON.stringify(fallbacks));
        return fallbacks;
      });
  }

  function getBookings() {
    return initStore();
  }

  function addBooking(bookingData) {
    return getBookings().then(function (list) {
      var idNum = Math.floor(Math.random() * 90000) + 10000;
      var newBooking = {
        id: "FCA-2026-" + idNum,
        userId: bookingData.userId,
        vehicleId: bookingData.vehicleId,
        pickupLoc: bookingData.pickupLoc || 'Mumbai Airport Hub T2',
        dropoffLoc: bookingData.dropoffLoc || 'Pune Hinjewadi Hub',
        startDate: bookingData.startDate || new Date().toISOString().split('T')[0],
        endDate: bookingData.endDate || new Date().toISOString().split('T')[0],
        distance: parseInt(bookingData.distance) || 120,
        days: parseInt(bookingData.days) || 1,
        totalPrice: parseFloat(bookingData.totalPrice) || 5000,
        vehicleName: bookingData.vehicleName || 'Standard Vehicle',
        vehicleInfo: bookingData.vehicleInfo || '',
        fuelType: bookingData.fuelType || 'gasoline',
        status: "confirmed",
        createdAt: new Date().toISOString()
      };

      list.push(newBooking);
      localStorage.setItem(BOOKINGS_KEY, JSON.stringify(list));
      
      // Store latest booking under separate key for easy access in confirmation
      localStorage.setItem('FC_LATEST_BOOKING', JSON.stringify(newBooking));
      return newBooking;
    });
  }

  function getBookingsByUser(userId) {
    return getBookings().then(function (list) {
      return list.filter(function (b) {
        return b.userId === userId;
      });
    });
  }

  function getLatestBooking() {
    var str = localStorage.getItem('FC_LATEST_BOOKING');
    if (str) {
      try {
        return JSON.parse(str);
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  // Self-initializing
  initStore();

  window.BookingStore = {
    addBooking: addBooking,
    getBookingsByUser: getBookingsByUser,
    getLatestBooking: getLatestBooking
  };
})();
