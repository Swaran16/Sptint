/* ===========================================================
   FleetCommand AI — Shared Shell Components (sidebar + header)
   Injected via JS so every screen in a role shares one source
   of truth instead of duplicated markup per page.
   =========================================================== */

const FC_ICONS = {
  dashboard: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>',
  trips: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 3v18M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3V6z"/></svg>',
  bookings: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M3 10h18M8 2v4M16 2v4"/></svg>',
  payments: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>',
  profile: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>',
  fleet: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 13l2-7h14l2 7"/><rect x="3" y="13" width="18" height="6" rx="1.5"/><circle cx="7.5" cy="19" r="1.3"/><circle cx="16.5" cy="19" r="1.3"/></svg>',
  earnings: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/></svg>',
  verifications: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M9 12l2 2 4-4"/></svg>',
  users: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-6 6.5-6s6.5 2.5 6.5 6"/><circle cx="18" cy="8" r="2.7"/><path d="M16 8.3A5.5 5.5 0 0121.5 14"/></svg>',
  reports: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
  settings: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.9 2.9l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.6V21a2 2 0 11-4 0v-.2a1.7 1.7 0 00-1-1.6 1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.9-2.9l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.6-1H3a2 2 0 110-4h.2a1.7 1.7 0 001.6-1 1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.9-2.9l.1.1a1.7 1.7 0 001.9.3H9a1.7 1.7 0 001-1.6V3a2 2 0 114 0v.2a1.7 1.7 0 001 1.6 1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.9 2.9l-.1.1a1.7 1.7 0 00-.3 1.9V9a1.7 1.7 0 001.6 1h.2a2 2 0 110 4h-.2a1.7 1.7 0 00-1.6 1z"/></svg>',
  logout: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>',
  bell: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 01-3.4 0"/></svg>',
  gear: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.9 2.9l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.6V21a2 2 0 11-4 0v-.2a1.7 1.7 0 00-1-1.6 1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.9-2.9l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.6-1H3a2 2 0 110-4h.2a1.7 1.7 0 001.6-1 1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.9-2.9l.1.1a1.7 1.7 0 001.9.3H9a1.7 1.7 0 001-1.6V3a2 2 0 114 0v.2a1.7 1.7 0 001 1.6 1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.9 2.9l-.1.1a1.7 1.7 0 00-.3 1.9V9a1.7 1.7 0 001.6 1h.2a2 2 0 110 4h-.2a1.7 1.7 0 00-1.6 1z"/></svg>',
  search: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/></svg>'
};

const FC_NAV = {
  user: [
    { key:'dashboard', label:'Dashboard', href:'dashboard.html', icon:'dashboard' },
    { key:'trips', label:'Trips', href:'trips.html', icon:'trips' },
    { key:'bookings', label:'Bookings', href:'bookings.html', icon:'bookings' },
    { key:'payments', label:'Payments', href:'payments.html', icon:'payments' },
    { key:'profile', label:'Profile', href:'profile.html', icon:'profile' },
  ],
  owner: [
    { key:'dashboard', label:'Dashboard', href:'dashboard.html', icon:'dashboard' },
    { key:'fleet', label:'My Fleet', href:'fleet.html', icon:'fleet' },
    { key:'drivers', label:'Drivers', href:'drivers.html', icon:'profile' },
    { key:'bookings', label:'Bookings', href:'bookings.html', icon:'bookings' },
    { key:'earnings', label:'Earnings', href:'earnings.html', icon:'earnings' },
    { key:'profile', label:'Profile', href:'profile.html', icon:'profile' },
  ],
  admin: [
    { key:'dashboard', label:'Dashboard', href:'dashboard.html', icon:'dashboard' },
    { key:'verifications', label:'Verifications', href:'verifications.html', icon:'verifications' },
    { key:'owners', label:'Owners List', href:'owners.html', icon:'users' },
    { key:'bookings', label:'Bookings', href:'bookings.html', icon:'bookings' },
    { key:'settings', label:'Settings', href:'settings.html', icon:'settings' },
  ],
  driver: [
    { key:'dashboard', label:'Dashboard', href:'dashboard.html', icon:'dashboard' },
    { key:'current-trip', label:'Current Trip', href:'current-trip.html', icon:'trips' },
    { key:'history', label:'Trip History', href:'history.html', icon:'earnings' }
  ]
};

const FC_ROLE_META = {
  user: { title:'FleetCommand AI', sub:'Enterprise Logistics', newBtn:{label:'New Booking', href:'bookings.html'} },
  owner:{ title:'FleetCommand AI', sub:'Owner Portal' },
  admin:{ title:'FleetCommand AI', sub:'Admin Portal' },
  driver:{ title:'FleetCommand AI', sub:'Driver Portal' }
};

function fcInitials(name){
  return name.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase();
}

function fcRenderShell({ role, active }){
  const session = fcRequireAuth(role);
  if(!session) return;
  const user = fcGetCurrentUser();
  const nav = FC_NAV[role];
  const meta = FC_ROLE_META[role];

  let sidebarHTML = '';
  if (role !== 'user') {
    sidebarHTML = `
      <aside class="sidebar">
        <div>
          <div class="brand"><span class="brand-mark">${roleMark()}</span>${meta.title}</div>
          <p class="brand-sub">${meta.sub}</p>
          <nav class="side-nav">
            ${nav.map(item => `
              <a href="${item.href}" class="${active===item.key ? 'active':''}">
                ${FC_ICONS[item.icon]} ${item.label}
              </a>`).join('')}
          </nav>
        </div>
        <div class="sidebar-bottom">
          ${meta.newBtn ? `<a href="${meta.newBtn.href}" class="btn btn-primary btn-block btn-sm">+ ${meta.newBtn.label}</a>` : ''}
          <a href="#" class="logout-link" id="logoutLink">${FC_ICONS.logout} Logout</a>
        </div>
      </aside>`;
  }

  let topbarHTML = '';
  if (role === 'user') {
    topbarHTML = `
      <header class="topbar" style="justify-content: space-between; padding: 16px 34px;">
        <button class="menu-toggle-btn" id="fcMenuToggleBtn" style="margin-right:12px;">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
        </button>
        <div class="brand" style="display:flex; align-items:center; gap:8px; margin-right:auto;">
          <span class="brand-mark" style="background: var(--indigo-600); width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; border-radius:8px; color:#fff;">
            ${roleMark()}
          </span>
          <span style="font-family: var(--font-display); font-weight:700; font-size:19px; color: var(--ink-900);">FleetCommand AI</span>
        </div>
        
        <nav class="topbar-nav" style="display:flex; gap:32px; font-size:14.5px; font-weight:600; color: var(--ink-600); margin: 0 auto 0 40px;">
          <a href="dashboard.html" class="${active==='dashboard' ? 'active':''}" style="color: ${active==='dashboard' ? 'var(--indigo-700)':'inherit'}; display: flex; align-items: center; gap: 6px;">
            Home
          </a>
          <a href="bookings.html" class="${active==='bookings' ? 'active':''}" style="color: ${active==='bookings' ? 'var(--indigo-700)':'inherit'}; display: flex; align-items: center; gap: 6px;">
            Bookings
          </a>
          <a href="trips.html" class="${active==='trips' ? 'active':''}" style="color: ${active==='trips' ? 'var(--indigo-700)':'inherit'}; display: flex; align-items: center; gap: 6px;">
            Trips
          </a>
        </nav>

        <div class="topbar-actions">
          <button class="icon-btn" title="Notifications">${FC_ICONS.bell}<span class="dot"></span></button>
          <div class="avatar-menu-wrap">
            <button class="avatar" id="avatarBtn">${fcInitials(user.name)}</button>
            <div class="avatar-dropdown" id="avatarDropdown">
              <div class="user-meta"><strong>${user.name}</strong><span>${user.email}</span></div>
              <a href="profile.html">${FC_ICONS.profile} My Profile</a>
              <a href="payments.html">${FC_ICONS.payments} Payments & Invoices</a>
              <button id="logoutBtn" style="border-top: 1px solid var(--line); border-radius: 0; margin-top: 5px; padding-top: 12px; color: var(--danger);">${FC_ICONS.logout} Logout</button>
            </div>
          </div>
        </div>
      </header>`;
  } else {
    topbarHTML = `
      <header class="topbar">
        <button class="menu-toggle-btn" id="fcMenuToggleBtn" style="margin-right:12px;">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
        </button>
        <div class="topbar-search">
          <div class="input-wrap">
            ${FC_ICONS.search}
            <input type="text" placeholder="Search trips, bookings, or IDs..." id="globalSearch">
          </div>
        </div>
        <div class="topbar-actions">
          <button class="icon-btn" title="Notifications">${FC_ICONS.bell}<span class="dot"></span></button>
          <a href="settings.html" class="icon-btn" title="Settings">${FC_ICONS.gear}</a>
          <div class="avatar-menu-wrap">
            <button class="avatar" id="avatarBtn">${fcInitials(user.name)}</button>
            <div class="avatar-dropdown" id="avatarDropdown">
              <div class="user-meta"><strong>${user.name}</strong><span>${user.email}</span></div>
              <a href="${role==='admin' ? 'settings.html' : 'profile.html'}">${FC_ICONS.profile} My Profile</a>
              <button id="logoutBtn">${FC_ICONS.logout} Logout</button>
            </div>
          </div>
        </div>
      </header>`;
  }

  const sidebarMount = document.getElementById('sidebar-mount');
  if (sidebarMount) {
    if (sidebarHTML) {
      sidebarMount.outerHTML = sidebarHTML;
    } else {
      sidebarMount.remove();
    }
  }

  const topbarMount = document.getElementById('topbar-mount');
  if (topbarMount) {
    topbarMount.outerHTML = topbarHTML;
  }

  const logoutLink = document.getElementById('logoutLink');
  if (logoutLink) {
    logoutLink.addEventListener('click', (e)=>{ e.preventDefault(); fcLogout(); });
  }

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', fcLogout);
  }

  const avBtn = document.getElementById('avatarBtn');
  if (avBtn) {
    avBtn.addEventListener('click', ()=>{
      document.getElementById('avatarDropdown').classList.toggle('open');
    });
  }
  document.addEventListener('click', (e)=>{
    const wrap = document.querySelector('.avatar-menu-wrap');
    if(wrap && !wrap.contains(e.target)) {
      const drop = document.getElementById('avatarDropdown');
      if (drop) drop.classList.remove('open');
    }
  });

  // Inject Floating Demo Portal Switcher for seamless workflow testing
  if(!document.getElementById('fcDemoSwitcher')) {
    const switcher = document.createElement('div');
    switcher.id = 'fcDemoSwitcher';
    switcher.innerHTML = `
      <div style="position:fixed; bottom:20px; right:20px; background:#1e1e2d; color:#fff; padding:10px 14px; border-radius:8px; box-shadow:0 6px 20px rgba(0,0,0,0.35); display:flex; gap:8px; align-items:center; font-family:system-ui, -apple-system, sans-serif; font-size:12px; z-index:99999; border:1px solid rgba(255,255,255,0.15);">
        <span style="font-weight:700; color:rgba(255,255,255,0.55); text-transform:uppercase; font-size:10px; letter-spacing:0.5px; margin-right:4px;">Demo Switcher:</span>
        <button onclick="fcDemoSwitch('admin')" style="background:${role==='admin'?'var(--indigo-600)':'rgba(255,255,255,0.1)'}; color:#fff; border:none; padding:5px 9px; border-radius:4px; font-weight:600; cursor:pointer; font-size:11px; transition:background 0.2s;">Admin</button>
        <button onclick="fcDemoSwitch('owner')" style="background:${role==='owner'?'var(--indigo-600)':'rgba(255,255,255,0.1)'}; color:#fff; border:none; padding:5px 9px; border-radius:4px; font-weight:600; cursor:pointer; font-size:11px; transition:background 0.2s;">Owner</button>
        <button onclick="fcDemoSwitch('driver')" style="background:${role==='driver'?'var(--indigo-600)':'rgba(255,255,255,0.1)'}; color:#fff; border:none; padding:5px 9px; border-radius:4px; font-weight:600; cursor:pointer; font-size:11px; transition:background 0.2s;">Driver</button>
        <button onclick="fcDemoSwitch('user')" style="background:${role==='user'?'var(--indigo-600)':'rgba(255,255,255,0.1)'}; color:#fff; border:none; padding:5px 9px; border-radius:4px; font-weight:600; cursor:pointer; font-size:11px; transition:background 0.2s;">User</button>
      </div>
    `;
    document.body.appendChild(switcher);
  }

  window.fcDemoSwitch = function(targetRole) {
    let email = '';
    let password = '';
    if(targetRole === 'admin') {
      email = 'admin@fleetcommand.ai';
      password = 'Admin@123';
    } else if(targetRole === 'owner') {
      email = 'owner@demo.com';
      password = 'Owner@123';
    } else if(targetRole === 'user') {
      email = 'user@demo.com';
      password = 'User@123';
    } else if(targetRole === 'driver') {
      const db = JSON.parse(localStorage.getItem('fc_users_db') || '[]');
      const drv = db.find(u => u.role === 'driver');
      if(drv) {
        email = drv.email;
        password = drv.password;
      } else {
        email = 'ramesh@demo.com';
        password = 'DRV-1001';
      }
    }
    
    const result = fcLogin(email, password);
    if(result.ok) {
      window.location.href = fcRootPath() + targetRole + '/dashboard.html';
    }
  }

  // Inject dynamic mobile responsiveness stylesheet
  injectResponsiveStyles();

  // Dynamic table wrapping to prevent mobile layout breaks
  document.querySelectorAll('table.data-table').forEach(table => {
    if (!table.parentElement.classList.contains('table-responsive')) {
      const wrapper = document.createElement('div');
      wrapper.className = 'table-responsive';
      table.parentNode.insertBefore(wrapper, table);
      wrapper.appendChild(table);
    }
  });

  // Bind Hamburger menu toggles and backdrop overlay controllers
  const toggleBtn = document.getElementById('fcMenuToggleBtn');
  if (toggleBtn) {
    if (role === 'user') {
      const topbarNav = document.querySelector('.topbar-nav');
      toggleBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (topbarNav) topbarNav.classList.toggle('mobile-open');
      });
      document.addEventListener('click', () => {
        if (topbarNav) topbarNav.classList.remove('mobile-open');
      });
    } else {
      const sidebar = document.querySelector('.sidebar');
      let backdropEl = document.getElementById('fcSidebarBackdrop');
      if (!backdropEl) {
        backdropEl = document.createElement('div');
        backdropEl.className = 'sidebar-backdrop';
        backdropEl.id = 'fcSidebarBackdrop';
        document.body.appendChild(backdropEl);
      }
      
      toggleBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (sidebar) sidebar.classList.toggle('open');
        backdropEl.classList.toggle('show');
      });
      
      backdropEl.addEventListener('click', () => {
        if (sidebar) sidebar.classList.remove('open');
        backdropEl.classList.remove('show');
      });
      
      if (sidebar) {
        sidebar.querySelectorAll('a').forEach(link => {
          link.addEventListener('click', () => {
            sidebar.classList.remove('open');
            backdropEl.classList.remove('show');
          });
        });
      }
    }
  }

  return { session, user };
}

function injectResponsiveStyles() {
  if (document.getElementById('fcResponsiveStyles')) return;
  const style = document.createElement('style');
  style.id = 'fcResponsiveStyles';
  style.textContent = `
    /* Mobile Hamburger Menu styles */
    .menu-toggle-btn {
      display: none;
      background: none;
      border: none;
      color: var(--ink-900);
      cursor: pointer;
      padding: 8px;
      align-items: center;
      justify-content: center;
    }
    .menu-toggle-btn svg {
      display: block;
    }
    
    /* Grid system layout definitions */
    .field-grid3 {
      display: grid;
      grid-template-columns: 1.2fr 1fr 0.8fr;
      gap: 14px;
    }
    .field-grid2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 14px;
    }

    /* Dynamic table scrolling containers */
    .panel {
      max-width: 100%;
      overflow: visible;
    }
    .table-responsive {
      width: 100%;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
      margin-bottom: 10px;
    }
    
    /* Pagination Styles */
    .pagination-controls {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 18px;
      font-size: 13px;
      font-family: var(--font-body);
      flex-wrap: wrap;
      gap: 12px;
    }
    .pagination-info {
      color: var(--ink-600);
      font-weight: 500;
    }
    .pagination-buttons {
      display: flex;
      gap: 8px;
      align-items: center;
    }
    
    /* Responsive breakpoints */
    @media (max-width: 780px) {
      .menu-toggle-btn {
        display: inline-flex;
      }
      
      .app-shell .sidebar {
        display: flex !important;
        position: fixed;
        top: 0;
        left: -260px;
        width: 250px;
        height: 100vh;
        z-index: 9999;
        transition: left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 5px 0 15px rgba(0,0,0,0.15);
      }
      .app-shell .sidebar.open {
        left: 0;
      }
      
      .sidebar-backdrop {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.4);
        z-index: 9998;
      }
      .sidebar-backdrop.show {
        display: block;
      }
      
      /* Client topbar nav dropdown */
      .topbar-nav {
        display: none !important;
      }
      .topbar-nav.mobile-open {
        display: flex !important;
        flex-direction: column;
        position: absolute;
        top: 70px;
        left: 0;
        width: 100%;
        background: #fff;
        border-bottom: 1px solid var(--line);
        padding: 16px 20px;
        gap: 12px !important;
        z-index: 999;
        box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05);
      }
      
      /* Responsive grid/two-column adjustments */
      .stat-grid {
        grid-template-columns: 1fr !important;
        gap: 16px !important;
      }
      .two-col {
        grid-template-columns: 1fr !important;
        gap: 20px !important;
      }
      .field-grid3 {
        grid-template-columns: 1fr !important;
        gap: 12px !important;
      }
      .field-grid2 {
        grid-template-columns: 1fr !important;
        gap: 12px !important;
      }
      .vehicle-pick-grid {
        grid-template-columns: 1fr !important;
        gap: 12px !important;
      }
      
      /* Layout padding overrides */
      .page-body {
        padding: 20px 16px 40px !important;
      }
      .topbar {
        padding: 12px 16px !important;
      }
      .topbar-search {
        max-width: 100% !important;
      }
      
      /* Responsive lists & details cards */
      .list-card {
        flex-direction: column;
        align-items: stretch;
        gap: 12px;
      }
      .list-card img {
        width: 100%;
        height: 120px;
      }
      .list-card .side-actions {
        align-items: flex-start;
        border-top: 1px solid var(--line);
        padding-top: 10px;
        margin-top: 4px;
      }
    }
  `;
  document.head.appendChild(style);
}

function roleMark(){
  return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12l7-9 4 4-7 9-4-4z"/><path d="M13 7l4-4 4 4-7 9"/></svg>';
}

/**
 * Paginates an array of items and renders pagination controls.
 */
function fcPaginate(items, currentPage, pageSize, controlsContainerId, onPageChange) {
  const totalItems = items.length;
  const totalPages = Math.ceil(totalItems / pageSize) || 1;
  
  let page = currentPage;
  if (page < 1) page = 1;
  if (page > totalPages) page = totalPages;

  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedItems = items.slice(startIndex, endIndex);

  const container = document.getElementById(controlsContainerId);
  if (container) {
    if (totalItems <= pageSize) {
      container.innerHTML = ''; 
    } else {
      container.innerHTML = `
        <div class="pagination-controls">
          <span class="pagination-info">Showing <strong>${startIndex + 1}</strong> to <strong>${Math.min(endIndex, totalItems)}</strong> of <strong>${totalItems}</strong> entries</span>
          <div class="pagination-buttons">
            <button class="btn btn-ghost btn-sm" ${page === 1 ? 'disabled style="opacity:0.4; cursor:not-allowed;"' : ''} onclick="window['${controlsContainerId}_changePage'](${page - 1})">Previous</button>
            <span style="display:inline-flex; align-items:center; padding: 0 10px; font-weight:600; color:var(--ink-900); font-size:12.5px;">Page ${page} of ${totalPages}</span>
            <button class="btn btn-ghost btn-sm" ${page === totalPages ? 'disabled style="opacity:0.4; cursor:not-allowed;"' : ''} onclick="window['${controlsContainerId}_changePage'](${page + 1})">Next</button>
          </div>
        </div>
      `;
      window[`${controlsContainerId}_changePage`] = onPageChange;
    }
  }

  return paginatedItems;
}
