// =====================================================================
// FleetCommand AI — Shared JavaScript Utilities
// =====================================================================

(function () {
  'use strict';

  // ── Sidebar ──────────────────────────────────────────────────────────
  window.initSidebar = function () {
    const sidebar  = document.getElementById('sidebar');
    const overlay  = document.getElementById('sidebarOverlay');
    const toggle   = document.getElementById('menuToggle');
    if (!sidebar) return;

    function openSidebar()  { sidebar.classList.add('open'); if (overlay) overlay.classList.add('open'); document.body.style.overflow = 'hidden'; }
    function closeSidebar() { sidebar.classList.remove('open'); if (overlay) overlay.classList.remove('open'); document.body.style.overflow = ''; }

    if (toggle)  toggle.addEventListener('click', openSidebar);
    if (overlay) overlay.addEventListener('click', closeSidebar);

    // Highlight active nav item
    const links = sidebar.querySelectorAll('.sidebar-nav-item[href]');
    const current = window.location.pathname.replace(/\\/g, '/');
    links.forEach(link => {
      const href = link.getAttribute('href').replace(/^\.\/|^\.\.\//g, '');
      if (current.endsWith(href) || current.endsWith(href.replace('.html', ''))) {
        link.classList.add('active');
      }
    });
  };

  // ── Scroll Reveal ─────────────────────────────────────────────────────
  window.initScrollReveal = function () {
    if (!('IntersectionObserver' in window)) {
      // Fallback: show all immediately
      document.querySelectorAll('.reveal').forEach(el => el.classList.add('revealed'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  };

  // ── Count-up Animation ────────────────────────────────────────────────
  window.initCountUp = function () {
    const elements = document.querySelectorAll('[data-count]');
    if (!elements.length) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animateCount(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    elements.forEach(el => observer.observe(el));
  };

  function animateCount(el) {
    const target   = parseFloat(el.dataset.count);
    const prefix   = el.dataset.prefix || '';
    const suffix   = el.dataset.suffix || '';
    const decimals = (el.dataset.count.split('.')[1] || '').length;
    const duration = 1200;
    const start    = performance.now();

    function update(now) {
      const elapsed  = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const ease     = 1 - Math.pow(1 - progress, 3); // easeOutCubic
      const current  = target * ease;
      el.textContent = prefix + (decimals > 0 ? current.toFixed(decimals) : Math.floor(current).toLocaleString()) + suffix;
      if (progress < 1) requestAnimationFrame(update);
      else el.textContent = prefix + (decimals > 0 ? target.toFixed(decimals) : target.toLocaleString()) + suffix;
    }
    requestAnimationFrame(update);
  }

  // ── Toast Notifications ───────────────────────────────────────────────
  window.showToast = function (message, type = 'info', duration = 3500) {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const icons = { success: '✓', error: '✕', warning: '⚠', info: 'ℹ' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span class="toast-msg">${message}</span>`;
    container.appendChild(toast);

    requestAnimationFrame(() => {
      requestAnimationFrame(() => toast.classList.add('show'));
    });

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 400);
    }, duration);
  };

  // ── Modal Helpers ─────────────────────────────────────────────────────
  window.openModal = function (id) {
    const overlay = document.getElementById(id);
    if (overlay) overlay.classList.add('open');
  };
  window.closeModal = function (id) {
    const overlay = document.getElementById(id);
    if (overlay) overlay.classList.remove('open');
  };
  window.initModals = function () {
    document.querySelectorAll('[data-modal-open]').forEach(btn => {
      btn.addEventListener('click', () => openModal(btn.dataset.modalOpen));
    });
    document.querySelectorAll('[data-modal-close]').forEach(btn => {
      btn.addEventListener('click', () => closeModal(btn.dataset.modalClose));
    });
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', e => {
        if (e.target === overlay) overlay.classList.remove('open');
      });
    });
    document.querySelectorAll('.modal-close').forEach(btn => {
      btn.addEventListener('click', () => {
        btn.closest('.modal-overlay').classList.remove('open');
      });
    });
  };

  // ── Tabs ──────────────────────────────────────────────────────────────
  window.initTabs = function () {
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const group  = btn.closest('[data-tab-group]') || document.body;
        const target = btn.dataset.tab;
        group.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        group.querySelectorAll('.tab-content-panel').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        const panel = group.querySelector(`[data-tab-content="${target}"]`) || document.getElementById(target);
        if (panel) panel.classList.add('active');
      });
    });
  };

  // ── Table Search + Filter ─────────────────────────────────────────────
  window.initTableSearch = function (tableId, inputId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    if (!input || !table) return;
    input.addEventListener('input', () => {
      const val = input.value.toLowerCase().trim();
      table.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = val === '' || row.textContent.toLowerCase().includes(val) ? '' : 'none';
      });
    });
  };

  // ── Table Sorting ─────────────────────────────────────────────────────
  window.initTableSort = function (tableId) {
    const table = document.getElementById(tableId);
    if (!table) return;
    table.querySelectorAll('thead th[data-sort]').forEach((th, idx) => {
      th.style.cursor = 'pointer';
      th.addEventListener('click', () => {
        const asc = th.dataset.asc !== 'true';
        th.dataset.asc = asc;
        const tbody = table.querySelector('tbody');
        const rows  = Array.from(tbody.querySelectorAll('tr'));
        rows.sort((a, b) => {
          const av = a.cells[idx]?.textContent.trim() || '';
          const bv = b.cells[idx]?.textContent.trim() || '';
          const an = parseFloat(av.replace(/[^0-9.]/g, ''));
          const bn = parseFloat(bv.replace(/[^0-9.]/g, ''));
          if (!isNaN(an) && !isNaN(bn)) return asc ? an - bn : bn - an;
          return asc ? av.localeCompare(bv) : bv.localeCompare(av);
        });
        rows.forEach(r => tbody.appendChild(r));
        table.querySelectorAll('thead th').forEach(h => { delete h.dataset.asc; h.textContent = h.textContent.replace(' ↑', '').replace(' ↓', ''); });
        th.textContent = th.textContent + (asc ? ' ↑' : ' ↓');
        th.dataset.asc = asc;
      });
    });
  };

  // ── Filter Select ─────────────────────────────────────────────────────
  window.initFilterSelect = function (selectId, tableId, colIdx) {
    const sel   = document.getElementById(selectId);
    const table = document.getElementById(tableId);
    if (!sel || !table) return;
    sel.addEventListener('change', () => {
      const val = sel.value.toLowerCase();
      table.querySelectorAll('tbody tr').forEach(row => {
        const cell = row.cells[colIdx];
        const text = cell ? cell.textContent.toLowerCase() : '';
        row.style.display = (!val || text.includes(val)) ? '' : 'none';
      });
    });
  };

  // ── Upload Zone Drag & Drop ───────────────────────────────────────────
  window.initUploadZones = function () {
    document.querySelectorAll('.upload-zone').forEach(zone => {
      const input = zone.querySelector('input[type=file]');
      zone.addEventListener('click', () => input && input.click());
      zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragging'); });
      zone.addEventListener('dragleave', () => zone.classList.remove('dragging'));
      zone.addEventListener('drop', e => {
        e.preventDefault(); zone.classList.remove('dragging');
        const files = e.dataTransfer.files;
        if (files.length) handleFileUpload(zone, files[0]);
      });
      if (input) {
        input.addEventListener('change', () => { if (input.files[0]) handleFileUpload(zone, input.files[0]); });
      }
    });
  };
  function handleFileUpload(zone, file) {
    const sub = zone.querySelector('.upload-zone-sub');
    if (sub) sub.textContent = `✓ ${file.name} (${(file.size / 1024).toFixed(0)} KB)`;
    zone.style.borderColor = 'var(--success)';
  }

  // ── Form Validation ───────────────────────────────────────────────────
  window.validateForm = function (formEl) {
    let valid = true;
    formEl.querySelectorAll('[required]').forEach(input => {
      input.classList.remove('error');
      const hint = input.parentNode.querySelector('.form-error');
      if (!input.value.trim()) {
        input.classList.add('error');
        if (hint) hint.textContent = 'This field is required.';
        valid = false;
      } else if (hint) hint.textContent = '';
    });
    return valid;
  };

  // ── Notification Bell Dropdown ────────────────────────────────────────
  window.initNotificationBell = function () {
    const bell = document.getElementById('notificationBtn');
    const panel = document.getElementById('notificationPanel');
    if (!bell || !panel) return;

    bell.addEventListener('click', e => {
      e.stopPropagation();
      panel.classList.toggle('open');
    });
    document.addEventListener('click', () => panel.classList.remove('open'));

    if (window.APP_DATA && window.APP_DATA.notifications) {
      const list = panel.querySelector('.notif-list');
      if (list) {
        list.innerHTML = APP_DATA.notifications.map(n => `
          <div class="notif-item ${n.unread ? 'unread' : ''}">
            <div class="notif-dot ${n.unread ? '' : 'read'}"></div>
            <div>
              <div class="notif-msg">${n.message}</div>
              <div class="notif-time">${n.time}</div>
            </div>
          </div>
        `).join('');
      }
    }
  };

  // ── Stagger Animation Helper ──────────────────────────────────────────
  window.staggerReveal = function (selector, delayIncrement = 60) {
    document.querySelectorAll(selector).forEach((el, i) => {
      el.style.transitionDelay = `${i * delayIncrement}ms`;
      el.classList.add('reveal');
    });
    initScrollReveal();
  };

  // ── Format Helpers ────────────────────────────────────────────────────
  window.fmt = {
    currency: (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n),
    number:   (n) => new Intl.NumberFormat('en-US').format(n),
    date:     (s) => new Date(s).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    time:     (s) => new Date(s).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    datetime: (s) => new Date(s).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
    initials: (name) => name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2),
    statusBadge: (status) => {
      const map = {
        active: 'badge-success', confirmed: 'badge-cyan', pending: 'badge-warning',
        completed: 'badge-neutral', cancelled: 'badge-error', in_progress: 'badge-primary',
        approved: 'badge-success', rejected: 'badge-error', awaiting_review: 'badge-warning',
        flagged: 'badge-error', in_review: 'badge-warning', pending_docs: 'badge-warning',
        available: 'badge-success', maintenance: 'badge-warning', on_trip: 'badge-cyan',
        online: 'badge-success', offline: 'badge-neutral', paid: 'badge-success',
        refunded: 'badge-warning', suspended: 'badge-error', missing_docs: 'badge-error',
      };
      return `<span class="badge ${map[status] || 'badge-neutral'}">${status.replace(/_/g, ' ').toUpperCase()}</span>`;
    },
  };

  // ── Populate User Info ────────────────────────────────────────────────
  window.populateUserInfo = function () {
    if (!window.APP_DATA) return;
    const s = APP_DATA.session;
    document.querySelectorAll('[data-user-name]').forEach(el => el.textContent = s.name);
    document.querySelectorAll('[data-user-email]').forEach(el => el.textContent = s.email);
    document.querySelectorAll('[data-user-role]').forEach(el => el.textContent = s.role);
    document.querySelectorAll('[data-user-initials]').forEach(el => el.textContent = fmt.initials(s.name));
  };

  // ── Auto-init on DOMContentLoaded ────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
    initScrollReveal();
    initCountUp();
    initTabs();
    initModals();
    initUploadZones();
    initNotificationBell();
    populateUserInfo();
    document.body.classList.add('page-fade');
  });

})();
