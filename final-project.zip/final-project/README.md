# FleetCommand AI — Enterprise Fleet Management System

Welcome to **FleetCommand AI**, a high-fidelity, interactive prototype of a next-generation fleet management and enterprise logistics platform. This application features three distinct user portals (Customer, Fleet Owner, and Admin), coordinating booking lifecycles and validation workflows completely client-side.

---

## ⚡ Key Highlights & Architecture

- **Zero-Backend, LocalStorage Database**: Fully static implementation. All registrations, fleet management, driver rosters, bookings, and compliance statuses are stored, shared, and updated directly inside the browser's `localStorage` engine.
- **Dynamic Layout & Shell Injection**: Page layouts, top navigation headers, left-sidebars, search functionality, and authentication guards are dynamically generated and injected via JavaScript, avoiding markup duplication.
- **Role-Based Guards**: Direct folder-level authorization. Pages in role-specific folders (`user/`, `owner/`, `admin/`) dynamically intercept sessions to ensure correct user privileges.
- **Floating Demo Switcher**: A utility embedded in all dashboards that allows instant, single-click switching between Admin, Owner, and Customer (User) environments for rapid workflow testing.

---

## 👥 User Roles & Workflow Portals

### 1. Customer (User) Portal
The end-user dashboard tailored for corporate booking coordinators and logistics clients:
* **Booking Hub**: Interactive search widget specifying pickup coordinates, hire dates, and category filters (e.g., Heavy Carriers, Passenger MPVs, Compact City cars).
* **Live Trip Manager**: Real-time status display of active trips. Users can trigger states like **Start Trip**, **Complete Trip**, or **Cancel Trip**, which dynamically syncs across the database.
* **Payments & Billing**: Chronological ledger of trips, invoices, transaction references, payment channels (Cash vs. Online), and receipts.
* **KYC Profile Control**: Profile information manager featuring verification uploads for driving licenses or corporate IDs.

### 2. Fleet Owner Portal
Designed for commercial vehicle operators and logistic fleet managers:
* **Telemetry Dashboard**: High-level metrics tracking Total Earnings, Active Fleet counts, Driver Availability, and Trip completions.
* **Fleet Catalog Manager**: Register vehicles with registration plates, categories, and documents. Adding a vehicle launches a compliance review with the Admin.
* **Driver Roster**: Add drivers, manage license keys, and assign drivers to active vehicles once their records are verified.
* **Operations Desk**: Accept, reject, or provision incoming customer bookings, assigning appropriate vehicle-driver pairs to confirmed trips.
* **Earnings Analytics**: Charts showing cash receipts, online invoices, transaction fees, and net payouts.

### 3. Admin (Superuser) Portal
The global command center for platform operations:
* **Platform Health Desk**: Tracks total users, aggregate earnings, registered owners, and pending compliance queues.
* **Compliance Control Center**: Reviews and approves/rejects KYC uploads, business license requests, vehicle registrations, and driver licenses.
* **Fleet Bookings Audit**: Master list of all bookings across the platform.
* **Settings Control**: Configure platform commission rates, automatic KYC modes, and payment gateway simulation configurations.

---

## 📂 Project Directory Structure

Below is the workspace structure. Click on any file name to view its source code:

```
fleetcommand-ai/
├── admin/                           # Admin Portal Screens
│   ├── [bookings.html](fleetcommand-ai/admin/bookings.html)       # Global bookings audit ledger
│   ├── [dashboard.html](fleetcommand-ai/admin/dashboard.html)     # Master system analytics dashboard
│   ├── [owners.html](fleetcommand-ai/admin/owners.html)           # Fleet operators directory
│   ├── [reports.html](fleetcommand-ai/admin/reports.html)         # Platform reports and earnings audits
│   ├── [settings.html](fleetcommand-ai/admin/settings.html)       # Fee configurations and compliance switches
│   ├── [users.html](fleetcommand-ai/admin/users.html)             # Registered customer ledger
│   └── [verifications.html](fleetcommand-ai/admin/verifications.html) # Compliance review queues (KYC, DL, RC)
│
├── owner/                           # Fleet Owner Portal Screens
│   ├── [bookings.html](fleetcommand-ai/owner/bookings.html)       # Booking assignment & confirmation desk
│   ├── [dashboard.html](fleetcommand-ai/owner/dashboard.html)     # Business overview dashboard
│   ├── [drivers.html](fleetcommand-ai/owner/drivers.html)         # Driver registry & vehicle assignments
│   ├── [earnings.html](fleetcommand-ai/owner/earnings.html)       # Financial payouts & ledger breakdown
│   ├── [fleet.html](fleetcommand-ai/owner/fleet.html)             # Vehicle additions & compliance statuses
│   └── [profile.html](fleetcommand-ai/owner/profile.html)         # Corporate metadata editor
│
├── user/                            # Customer Portal Screens
│   ├── [bookings.html](fleetcommand-ai/user/bookings.html)       # Vehicle explorer and booking workspace
│   ├── [dashboard.html](fleetcommand-ai/user/dashboard.html)     # Home interface with booking parameters
│   ├── [payments.html](fleetcommand-ai/user/payments.html)       # Invoices, transactions, and download logs
│   ├── [profile.html](fleetcommand-ai/user/profile.html)         # User profile and KYC document uploader
│   └── [trips.html](fleetcommand-ai/user/trips.html)             # Real-time trip status manager
│
├── assets/                          # Stylesheets and JavaScript Components
│   ├── css/
│   │   ├── [auth.css](ffleetcommand-ai/assets/css/auth.css)       # Layout styles for login, register, recovery
│   │   ├── [base.css](fleetcommand-ai/assets/css/base.css)       # Design tokens, variables, global defaults
│   │   ├── [dashboard.css](fleetcommand-ai/assets/css/dashboard.css)  # Shared dashboard visual classes
│   │   └── [landing.css](fleetcommand-ai/assets/css/landing.css)    # Landing page marketing styles
│   └── js/
│       ├── [auth.js](fleetcommand-ai/assets/js/auth.js)         # LocalStorage seeding, login/logout, route guards
│       └── [components.js](fleetcommand-ai/assets/js/components.js)   # Header/sidebar layouts and float demo switcher
│
├── [index.html](fleetcommand-ai/index.html)                       # Public landing page
├── [login.html](fleetcommand-ai/login.html)                       # Core sign-in portal (with credentials)
├── [register.html](fleetcommand-ai/register.html)                 # Role signup workspace
└── [forgot-password.html](fleetcommand-ai/forgot-password.html)         # Forgot password mockup
```

---

## 💾 LocalStorage Database Architecture

Data persists in the browser using the following keys:

| LocalStorage Key | Target Content Schema / Purpose |
| :--- | :--- |
| `fc_users_db` | User profiles list, password keys, registration metadata, and system privileges. |
| `fc_session` | Encrypted representation of the current logged-in identity for route guard validation. |
| `fc_bookings` | Master array of customer rentals, tracking vehicle, driver, dates, payments, and trip lifecycle. |
| `fc_drivers` | Seeded driver accounts owned by Fleet Partners, referencing license keys and verification status. |
| `fc_fleet` | Seeded vehicle models containing fuel capacity, day rates, registration details, and approvals. |
| `fc_admin_verifications` | Unified compliance verification queue managed by the Admin. |

---

## 🔄 Core Life Cycle Flows

### A. The Booking Lifecycle
1. **Initiation**: A Customer navigates to [bookings.html](fleetcommand-ai/user/bookings.html), chooses a vehicle category, enters trip parameters (locations, dates), chooses payment method (Cash/Online), and submits.
2. **Review**: The booking enters the Owner Portal's bookings log with a status of `Pending Approval`.
3. **Provisioning**: The Fleet Owner reviews the request, assigns a verified vehicle and an available driver, and approves the booking.
4. **Execution**: The booking transitions to `Confirmed`. The Customer can view the assigned driver/vehicle, then click **Start Trip** in [trips.html](fleetcommand-ai/user/trips.html), shifting status to `Ongoing`.
5. **Completion**: Once the trip concludes, the Customer clicks **Complete Trip**, finalizing the invoice transaction and recording the payout inside Owner's `earnings.html`.

### B. The Compliance Verification Flow
1. **Creation**: An Owner adds a new vehicle in `fleet.html` or a new driver in `drivers.html`, or a User uploads KYC documents in `profile.html`.
2. **Queueing**: The status defaults to `Pending Verification`, and a new request is pushed into the `fc_admin_verifications` array.
3. **Audit**: The Admin reviews the document image in the Verifications tab.
4. **Update**: Admin approves or rejects the document, immediately updating the status of the vehicle, driver, or user profile in the database.

---

## 🚀 Getting Started

1. **Serve the Application**:
   Since the app runs on pure static assets, you can run it using any simple local server or directly open `index.html` in your web browser:
   ```bash
   # Example: using Node.js static server
   npx serve ./
   ```
2. **Quick Demo Logins**:
   The login page has preset accounts to allow instant exploration of the roles:
   - **Admin Superuser**: `admin@fleetcommand.ai` / `Admin@123`
   - **Fleet Owner**: `owner@demo.com` / `Owner@123`
   - **Customer**: `user@demo.com` / `User@123`
