/* ===========================================================
   FleetCommand AI — Mock Auth Layer
   Data lives in localStorage so the demo persists between pages.
   =========================================================== */
const FC_DB_KEY = 'fc_users_db';
const FC_SESSION_KEY = 'fc_session';

/* ---- Seed demo accounts (created once) ---- */
function fcSeedDB(){
  let db = JSON.parse(localStorage.getItem(FC_DB_KEY) || 'null');
  
  const standardSeeds = [
    {
      role: 'admin',
      name: 'Priya Nandan',
      email: 'admin@fleetcommand.ai',
      password: 'Admin@123',
      phone: '+1 (555) 000-1111',
      fixed: true
    },
    {
      role: 'user',
      name: 'Alexander Sterling',
      email: 'user@demo.com',
      password: 'User@123',
      phone: '+1 (555) 234-8901',
      jobRole: 'Fleet Operations Manager'
    },
    {
      role: 'owner',
      name: 'Marcus Chen',
      email: 'owner@demo.com',
      password: 'Owner@123',
      phone: '+1 (555) 678-2233',
      company: 'SwiftLogistics Partners'
    },
    {
      role: 'owner',
      name: 'Rajesh Gupta',
      email: 'owner2@demo.com',
      password: 'Owner@123',
      phone: '+91 99999 88888',
      company: 'Delhi Logistics Corp'
    },
    {
      role: 'owner',
      name: 'Deepak Shinde',
      email: 'owner3@demo.com',
      password: 'Owner@123',
      phone: '+91 77777 66666',
      company: 'Pune Cargo Transport'
    },
    {
      role: 'owner',
      name: 'Karthik Rao',
      email: 'owner4@demo.com',
      password: 'Owner@123',
      phone: '+91 88888 99999',
      company: 'Bangalore Transit Co'
    },
    {
      role: 'driver',
      name: 'Ramesh Kumar',
      email: 'ramesh@demo.com',
      password: 'DRV-1001',
      driverId: 'DRV-1001',
      phone: '+91 98765 43210',
      license: 'DL-1420210098765',
      ownerEmail: 'owner@demo.com',
      status: 'Verified'
    },
    {
      role: 'driver',
      name: 'Suresh Singh',
      email: 'suresh@demo.com',
      password: 'DRV-1002',
      driverId: 'DRV-1002',
      phone: '+91 98765 43222',
      license: 'DL-1220190012345',
      ownerEmail: 'owner@demo.com',
      status: 'Verified'
    }
  ];

  if(!db){
    db = standardSeeds;
    localStorage.setItem(FC_DB_KEY, JSON.stringify(db));
  } else {
    // Migration/Sync: ensure standard seed emails are present and correct
    let changed = false;
    standardSeeds.forEach(seed => {
      let idx = db.findIndex(u => u.email.toLowerCase() === seed.email.toLowerCase());
      if(idx === -1) {
        db.push(seed);
        changed = true;
      } else {
        if(seed.role === 'driver') {
          const current = db[idx];
          if(current.password !== seed.password || current.driverId !== seed.driverId) {
            db[idx] = { ...current, ...seed };
            changed = true;
          }
        }
      }
    });

    // Remove legacy driver username entries to avoid conflicts
    const initialLen = db.length;
    db = db.filter(u => u.email !== 'DRV-1001' && u.email !== 'DRV-1002');
    if(db.length !== initialLen) {
      changed = true;
    }

    if(changed) {
      localStorage.setItem(FC_DB_KEY, JSON.stringify(db));
    }
  }

  // Seed bookings globally if not exists or if we need to enrich mock database for pagination
  let bookings = JSON.parse(localStorage.getItem('fc_bookings') || 'null');
  if(!bookings || bookings.length < 12) {
    bookings = [
      {
        id: 'FC-88122',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Hyundai Creta',
        pickup: 'Bangalore Airport T1',
        dropoff: 'Indiranagar, Bangalore',
        details: '3 Days Rental (With Driver)',
        totalCost: 10500,
        advancePaid: 2100,
        remainingBalance: 8400,
        status: 'Awaiting Final Payment',
        driverName: 'Suresh Singh',
        driverPhone: '+91 98765 43222',
        driverId: 'suresh@demo.com',
        date: '26 Oct, 2023'
      },
      {
        id: 'FC-77211',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Toyota Innova Crysta',
        pickup: 'Bandra Kurla Complex',
        dropoff: 'Mumbai Airport T2',
        details: '1 Day Rental (Self-Drive)',
        totalCost: 9130,
        advancePaid: 5700,
        remainingBalance: 3430,
        status: 'Pending Owner Approval',
        driverName: '',
        driverPhone: '',
        date: '27 Oct, 2023'
      },
      {
        id: 'FC-99100',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'BharatBenz Hauler',
        pickup: 'Pune Chakan Industrial Area',
        dropoff: 'Nhava Sheva Port',
        details: 'Interstate Delivery (With Driver)',
        totalCost: 14500,
        advancePaid: 2900,
        remainingBalance: 11600,
        status: 'Pending Owner Approval',
        driverName: '',
        driverPhone: '',
        date: '28 Oct, 2023'
      },
      {
        id: 'FC-99101',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Maruti Suzuki Swift',
        pickup: 'Thane West',
        dropoff: 'Pune Station',
        details: '2 Days Rental (With Driver)',
        totalCost: 4500,
        advancePaid: 900,
        remainingBalance: 3600,
        status: 'Pending Owner Approval',
        driverName: '',
        driverPhone: '',
        date: '29 Oct, 2023'
      },
      {
        id: 'FC-99102',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'Tata Ace',
        pickup: 'Mumbai Central',
        dropoff: 'Panvel Hub',
        details: 'Intrastate Logistics (With Driver)',
        totalCost: 5600,
        advancePaid: 1120,
        remainingBalance: 4480,
        status: 'Pending Owner Approval',
        driverName: '',
        driverPhone: '',
        date: '30 Oct, 2023'
      },
      {
        id: 'FC-90011',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'Tata Ace',
        pickup: 'Delhi Cargo Terminal',
        dropoff: 'Noida Logistics Hub',
        details: 'Intrastate Delivery (With Driver)',
        totalCost: 8500,
        advancePaid: 1700,
        remainingBalance: 6800,
        status: 'Confirmed',
        driverName: 'Ramesh Kumar',
        driverPhone: '+91 98765 43210',
        driverId: 'ramesh@demo.com',
        date: '08 Jul, 2026'
      },
      {
        id: 'FC-90012',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Hyundai Creta',
        pickup: 'Pune Station',
        dropoff: 'Mumbai Airport',
        details: '2 Days Rental (With Driver)',
        totalCost: 7500,
        advancePaid: 1500,
        remainingBalance: 6000,
        status: 'Confirmed',
        driverName: 'Ramesh Kumar',
        driverPhone: '+91 98765 43210',
        driverId: 'ramesh@demo.com',
        date: '09 Jul, 2026'
      },
      {
        id: 'FC-90013',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'BharatBenz Hauler',
        pickup: 'Thane Industrial',
        dropoff: 'Nhava Sheva Port',
        details: 'Intrastate Delivery (With Driver)',
        totalCost: 9500,
        advancePaid: 1900,
        remainingBalance: 7600,
        status: 'Confirmed',
        driverName: 'Suresh Singh',
        driverPhone: '+91 98765 43222',
        driverId: 'suresh@demo.com',
        date: '10 Jul, 2026'
      },
      {
        id: 'FC-88219',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'BharatBenz Hauler',
        pickup: 'Delhi Hub',
        dropoff: 'Mumbai Port',
        details: 'Interstate Heavy Haul (With Driver)',
        totalCost: 12400,
        advancePaid: 12400,
        remainingBalance: 0,
        status: 'Completed',
        driverName: 'Ramesh Kumar',
        driverPhone: '+91 98765 43210',
        driverId: 'ramesh@demo.com',
        date: '24 Oct, 2025'
      },
      {
        id: 'FC-88220',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Hyundai Creta',
        pickup: 'Pune Airport',
        dropoff: 'Mahabaleshwar',
        details: '3 Days Rental (With Driver)',
        totalCost: 9500,
        advancePaid: 9500,
        remainingBalance: 0,
        status: 'Completed',
        driverName: 'Ramesh Kumar',
        driverPhone: '+91 98765 43210',
        driverId: 'ramesh@demo.com',
        date: '25 Oct, 2025'
      },
      {
        id: 'FC-88221',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'Tata Ace',
        pickup: 'Mumbai Port',
        dropoff: 'Pune Hub',
        details: 'Heavy Cargo Delivery (With Driver)',
        totalCost: 7500,
        advancePaid: 7500,
        remainingBalance: 0,
        status: 'Completed',
        driverName: 'Ramesh Kumar',
        driverPhone: '+91 98765 43210',
        driverId: 'ramesh@demo.com',
        date: '26 Oct, 2025'
      },
      {
        id: 'FC-88104',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Toyota Innova Crysta',
        pickup: 'Mumbai Airport T2',
        dropoff: 'Lonavala',
        details: '1 Day Rental (With Driver)',
        totalCost: 4720,
        advancePaid: 4720,
        remainingBalance: 0,
        status: 'Completed',
        driverName: 'Suresh Singh',
        driverPhone: '+91 98765 43222',
        driverId: 'suresh@demo.com',
        date: '23 Oct, 2025'
      },
      {
        id: 'FC-88105',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Toyota Innova Crysta',
        pickup: 'Pune Baner',
        dropoff: 'Mumbai Airport',
        details: '2 Days Rental (With Driver)',
        totalCost: 8200,
        advancePaid: 8200,
        remainingBalance: 0,
        status: 'Completed',
        driverName: 'Suresh Singh',
        driverPhone: '+91 98765 43222',
        driverId: 'suresh@demo.com',
        date: '22 Oct, 2025'
      },
      {
        id: 'FC-88106',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'Tata Ace',
        pickup: 'Chakan Industrial',
        dropoff: 'Panvel Port',
        details: 'Intrastate Cargo Delivery (With Driver)',
        totalCost: 6500,
        advancePaid: 6500,
        remainingBalance: 0,
        status: 'Completed',
        driverName: 'Suresh Singh',
        driverPhone: '+91 98765 43222',
        driverId: 'suresh@demo.com',
        date: '21 Oct, 2025'
      },
      {
        id: 'FC-99901',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Hyundai Creta',
        pickup: 'Bangalore Airport',
        dropoff: 'Whitefield',
        details: '2 Days Rental (Self-Drive)',
        totalCost: 5000,
        advancePaid: 1000,
        remainingBalance: 4000,
        status: 'Cancelled',
        driverName: '',
        driverPhone: '',
        date: '10 Nov, 2023'
      },
      {
        id: 'FC-99902',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'Tata Ace',
        pickup: 'Bandra BKC',
        dropoff: 'Thane Hub',
        details: 'Express Cargo Delivery',
        totalCost: 4200,
        advancePaid: 840,
        remainingBalance: 3360,
        status: 'Cancelled',
        driverName: '',
        driverPhone: '',
        date: '11 Nov, 2023'
      },
      {
        id: 'FC-99903',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'car',
        vehicleName: 'Maruti Suzuki Swift',
        pickup: 'Pune Station',
        dropoff: 'Lonavala',
        details: '3 Days Rental (Self-Drive)',
        totalCost: 4500,
        advancePaid: 900,
        remainingBalance: 3600,
        status: 'Cancelled',
        driverName: '',
        driverPhone: '',
        date: '12 Nov, 2023'
      },
      {
        id: 'FC-99904',
        userEmail: 'user@demo.com',
        userName: 'Alexander Sterling',
        service: 'transport',
        vehicleName: 'BharatBenz Hauler',
        pickup: 'Delhi Cargo Hub',
        dropoff: 'Gurugram Sector 14',
        details: 'Freight Dispatch Delivery',
        totalCost: 11000,
        advancePaid: 2200,
        remainingBalance: 8800,
        status: 'Cancelled',
        driverName: '',
        driverPhone: '',
        date: '13 Nov, 2023'
      }
    ];
    localStorage.setItem('fc_bookings', JSON.stringify(bookings));
  }

  return db;
}

function fcGetDB(){ return fcSeedDB(); }
function fcSaveDB(db){ localStorage.setItem(FC_DB_KEY, JSON.stringify(db)); }

/* ---- Register ---- */
function fcRegister({name, email, phone, password, role, extra}){
  const db = fcGetDB();
  if(db.find(u => u.email.toLowerCase() === email.toLowerCase())){
    return { ok:false, message: 'An account with this email already exists.' };
  }
  const user = { role, name, email, password, phone, ...extra };
  db.push(user);
  fcSaveDB(db);
  fcSetSession(user);
  return { ok:true, user };
}

/* ---- Login ---- */
function fcLogin(email, password){
  const db = fcGetDB();
  const user = db.find(u => u.email.toLowerCase() === email.toLowerCase());
  if(!user) return { ok:false, message: 'No account found for that email.' };
  if(user.password !== password) return { ok:false, message: 'Incorrect password. Please try again.' };
  fcSetSession(user);
  return { ok:true, user };
}

function fcSetSession(user){
  const session = { email:user.email, role:user.role, name:user.name };
  localStorage.setItem(FC_SESSION_KEY, JSON.stringify(session));
}

function fcGetSession(){
  return JSON.parse(localStorage.getItem(FC_SESSION_KEY) || 'null');
}

function fcGetCurrentUser(){
  const session = fcGetSession();
  if(!session) return null;
  const db = fcGetDB();
  return db.find(u => u.email === session.email) || null;
}

function fcUpdateCurrentUser(patch){
  const session = fcGetSession();
  if(!session) return;
  const db = fcGetDB();
  const idx = db.findIndex(u => u.email === session.email);
  if(idx > -1){
    db[idx] = { ...db[idx], ...patch };
    fcSaveDB(db);
    if(patch.name) fcSetSession(db[idx]);
  }
}

function fcLogout(){
  localStorage.removeItem(FC_SESSION_KEY);
  window.location.href = fcRootPath() + 'login.html';
}

/* Works out how many folders deep the current page is, so links to
   root-level pages (login.html, index.html) resolve correctly from
   /user/, /owner/ and /admin/ subfolders. */
function fcRootPath(){
  const path = window.location.pathname;
  if(path.includes('/user/') || path.includes('/owner/') || path.includes('/admin/') || path.includes('/driver/')){
    return '../';
  }
  return '';
}

/* Guards a dashboard page: redirects to login if not authenticated,
   or if the session role does not match the page's required role. */
function fcRequireAuth(requiredRole){
  const session = fcGetSession();
  if(!session){
    const path = window.location.pathname;
    if(path.endsWith('user/bookings.html') || path.endsWith('user/bookings')) {
      return { email: 'guest@demo.com', role: 'user', name: 'Guest User', guest: true };
    }
    window.location.href = fcRootPath() + 'login.html';
    return null;
  }
  if(requiredRole && session.role !== requiredRole){
    window.location.href = fcRootPath() + session.role + '/dashboard.html';
    return null;
  }
  return session;
}

function fcToast(message, type=''){
  let el = document.getElementById('toast');
  if(!el){
    el = document.createElement('div');
    el.id = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.className = type;
  requestAnimationFrame(()=> el.classList.add('show'));
  clearTimeout(el._t);
  el._t = setTimeout(()=> el.classList.remove('show'), 2600);
}

fcSeedDB();
